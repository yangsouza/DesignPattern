package Hospital.Modelo;

import java.time.LocalDateTime;

/**
 * Representa um registro de acesso a um prontuário eletrônico.
 */
public class RegistroAcesso {
    private String medicoCrm;
    private String pacienteCpf;
    private LocalDateTime horarioAcesso;
    private String tipoOperacao; // Ex: "LEITURA", "EDICAO"

    public RegistroAcesso(String medicoCrm, String pacienteCpf, String tipoOperacao) {
        this.medicoCrm = medicoCrm;
        this.pacienteCpf = pacienteCpf;
        this.horarioAcesso = LocalDateTime.now();
        this.tipoOperacao = tipoOperacao;
    }

    @Override
    public String toString() {
        return String.format(
            "[%s] Operacao: %s | Médico (CRM): %s | Paciente (CPF): %s",
            horarioAcesso.withNano(0).toString(), // Remove nanos para legibilidade
            tipoOperacao,
            medicoCrm,
            pacienteCpf
        );
    }

    // Getters omitidos para brevidade, mas seriam úteis em uma aplicação real.
}