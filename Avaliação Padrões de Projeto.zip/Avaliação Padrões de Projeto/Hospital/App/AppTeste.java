package Hospital.App;

import Hospital.Auditoria.LoggerAuditoria;
import Hospital.Modelo.RegistroAcesso;

/**
 * Classe principal para demonstrar o uso do LoggerAuditoria Singleton.
 */
public class AppTeste {

    public static void main(String[] args) {
        // --- Teste 1: Garantindo a Única Instância ---
        System.out.println("--- Teste 1: Verificação de Instância Única ---");
        
        LoggerAuditoria logger1 = LoggerAuditoria.getInstancia();
        LoggerAuditoria logger2 = LoggerAuditoria.getInstancia();

        System.out.println("Logger 1 HashCode: " + logger1.hashCode());
        System.out.println("Logger 2 HashCode: " + logger2.hashCode());
        
        if (logger1 == logger2) {
            System.out.println("Resultado: As instâncias são as mesmas (Singleton OK!).\n");
        } else {
            System.err.println("Resultado: Falha do Singleton.");
        }

        // --- Teste 2: Uso em Múltiplas Threads (Teste de Thread-Safety) ---
        System.out.println("--- Teste 2: Acesso Simultâneo de Threads ---");
        
        // Simulação de vários acessos simultâneos de diferentes médicos
        for (int i = 1; i <= 5; i++) {
            final int threadId = i;
            Thread t = new Thread(() -> {
                LoggerAuditoria loggerThread = LoggerAuditoria.getInstancia();
                
                // Garantia de que a instância é a mesma dentro da thread
                if (loggerThread != logger1) {
                    System.err.println("ERRO: Thread obteve uma instância diferente!");
                    return;
                }
                
                String crm = "CRM-" + (1000 + threadId);
                String cpf = "CPF-" + (5000 + threadId);
                String op = (threadId % 2 == 0) ? "LEITURA" : "EDICAO";

                RegistroAcesso registro = new RegistroAcesso(crm, cpf, op);
                
                // O método registrarAcesso é chamado, garantindo que o arquivo 
                // seja escrito de forma síncrona/segura.
                loggerThread.registrarAcesso(registro);
            });
            t.start();
        }
    }
}