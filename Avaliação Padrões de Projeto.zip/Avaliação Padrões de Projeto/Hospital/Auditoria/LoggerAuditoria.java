package Hospital.Auditoria;

import Hospital.Modelo.RegistroAcesso;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Componente Singleton para centralizar o registro de logs de auditoria.
 * Garante uma única instância e acesso thread-safe.
 */
public final class LoggerAuditoria {

    // 1. Instância única e estática (volatile garante visibilidade entre threads)
    private static volatile LoggerAuditoria instancia;
    
    // Nome do arquivo de log local
    private static final String NOME_ARQUIVO = "auditoria_acessos.log";

    // 2. Construtor privado para evitar instanciação externa
    private LoggerAuditoria() {
        System.out.println("LoggerAuditoria: Instância criada (Singleton inicializado).");
        // Inicializações do sistema aqui (ex: abrir conexão com servidor de auditoria)
    }

    /**
     * Ponto de acesso global e thread-safe para a única instância do LoggerAuditoria.
     * Utiliza o padrão Double-Checked Locking para performance.
     * * @return A única instância de LoggerAuditoria.
     */
    public static LoggerAuditoria getInstancia() {
        // Primeira verificação (reduz a contenção de lock)
        if (instancia == null) {
            // Sincroniza o bloco apenas na primeira vez
            synchronized (LoggerAuditoria.class) {
                // Segunda verificação (garante que apenas uma thread crie a instância)
                if (instancia == null) {
                    instancia = new LoggerAuditoria();
                }
            }
        }
        return instancia;
    }

    /**
     * Registra um evento de acesso.
     * 1. Salva no arquivo local (simula registro seguro).
     * 2. Simula o envio ao servidor de auditoria externo.
     * * @param registro O objeto RegistroAcesso a ser logado.
     */
    public void registrarAcesso(RegistroAcesso registro) {
        String logLine = registro.toString();
        
        // 1. Gravação no Arquivo Seguro (Operação Síncrona)
        salvarEmArquivo(logLine);
        
        // 2. Transmissão para o Servidor de Auditoria Externo (Simulação)
        enviarParaServidorExterno(logLine);
    }

    /**
     * Método privado para simular a escrita em um arquivo seguro.
     * @param logLine A linha de log a ser escrita.
     */
    private synchronized void salvarEmArquivo(String logLine) {
        try (FileWriter fw = new FileWriter(NOME_ARQUIVO, true);
             PrintWriter pw = new PrintWriter(fw)) {
            pw.println(logLine);
            // System.out.println("LOG LOCAL: Registro salvo em " + NOME_ARQUIVO);
        } catch (IOException e) {
            System.err.println("ERRO ao escrever no arquivo de log: " + e.getMessage());
        }
    }

    /**
     * Método privado para simular a transmissão ao servidor externo.
     * @param logLine A linha de log a ser transmitida.
     */
    private void enviarParaServidorExterno(String logLine) {
        // Em um sistema real, aqui haveria chamadas de rede/API.
        System.out.println("LOG EXTERNO: Enviando para Servidor de Auditoria -> " + logLine);
    }
}