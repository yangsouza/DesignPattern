// Documento.java
package Empresa.Documento;

/**
 * Representa o documento a ser validado.
 */
public class Documento {
    private final String titulo;
    private final String conteudo;
    private final String autor;

    public Documento(String titulo, String conteudo, String autor) {
        this.titulo = titulo;
        this.conteudo = conteudo;
        this.autor = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getConteudo() {
        return conteudo;
    }

    public String getAutor() {
        return autor;
    }

    @Override
    public String toString() {
        return "Documento{" + "titulo='" + titulo + '\'' + ", autor='" + autor + '\'' + '}';
    }
}