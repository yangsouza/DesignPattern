// Main.java
package Empresa.Main;

import Empresa.Documento.Documento;
import Empresa.Validacao.*;

public class Main {

    public static void main(String[] args) {
        // 1. Cria as instâncias dos validadores (os "Handlers")
        Validador formatacao = new VerificacaoFormatacao();
        Validador conteudoSensivel = new ValidacaoConteudoSensivel();
        Validador direitosAutorais = new ConfirmacaoDireitosAutorais();
        Validador legal = new AutorizacaoDepartamentoLegal();

        // 2. Monta a cadeia de responsabilidade (ordem desejada)
        // formatacao -> conteudoSensivel -> direitosAutorais -> legal
        formatacao.setProximo(conteudoSensivel)
                  .setProximo(direitosAutorais)
                  .setProximo(legal);
        
        // O primeiro validador é o ponto de entrada da cadeia.
        Validador inicioDaCadeia = formatacao;


        // --- CENÁRIO 1: Documento APROVADO ---
        System.out.println("=== CENÁRIO 1: APROVAÇÃO COMPLETA ===");
        Documento docAprovado = new Documento("Relatório Anual", "Dados de Produção", "LegalCorp");
        System.out.println("Iniciando validação para: " + docAprovado);
        
        boolean aprovado1 = inicioDaCadeia.validar(docAprovado);
        
                System.out.println("\nResultado final: O documento foi " + (aprovado1 ? "**APROVADO**" : "**REJEITADO**") + ".");
            }
        }
    