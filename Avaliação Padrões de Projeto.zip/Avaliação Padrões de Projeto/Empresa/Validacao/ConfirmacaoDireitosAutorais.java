package Empresa.Validacao; // Corrigido de 'Empresa.Validacao'

import Empresa.Documento.Documento; // Corrigido de 'Empresa.Documento'

public class ConfirmacaoDireitosAutorais extends ValidadorBase {
    @Override
    protected boolean processarValidacao(Documento documento) {
        System.out.println("-> Executando: Confirmação de Direitos Autorais...");
        // Simulação: Apenas o autor "LegalCorp" tem direitos autorais válidos.
        if (documento.getAutor().equalsIgnoreCase("LegalCorp")) {
            System.out.println("   [OK] Direitos autorais confirmados.");
            return true;
        } else {
            System.out.println("   [FALHA] Direitos autorais rejeitados: Autor não autorizado.");
            return false;
        }
    }
}