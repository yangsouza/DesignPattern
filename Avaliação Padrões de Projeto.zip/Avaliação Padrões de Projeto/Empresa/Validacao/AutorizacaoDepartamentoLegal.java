package Empresa.Validacao; // Corrigido de 'Empresa.Validacao'

import Empresa.Documento.Documento; // Corrigido de 'Empresa.Documento'

public class AutorizacaoDepartamentoLegal extends ValidadorBase {
    @Override
    protected boolean processarValidacao(Documento documento) {
        System.out.println("-> Executando: Autorização do Departamento Legal...");
        // Simulação: O departamento legal aprova todos os documentos que chegam até ele.
        System.out.println("   [OK] Autorização legal concedida.");
        return true;
    }
}