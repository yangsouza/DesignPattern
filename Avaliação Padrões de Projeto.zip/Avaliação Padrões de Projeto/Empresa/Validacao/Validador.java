// Validador.java
package Empresa.Validacao;

import Empresa.Documento.Documento;

/**
 * Interface que define a estrutura do Chain of Responsibility.
 * Um Validador é o "Handler".
 */
public interface Validador {

    /**
     * Define o próximo validador na cadeia.
     * @param proximo O próximo validador.
     * @return O próprio Validador (para encadeamento fluente).
     */
    Validador setProximo(Validador proximo);

    /**
     * Tenta processar o documento.
     * @param documento O documento a ser validado.
     * @return true se todas as validações da cadeia foram aprovadas, false caso contrário.
     */
    boolean validar(Documento documento);
}