package Empresa.Validacao; // Corrigido de 'Empresa.Validacao'

import Empresa.Documento.Documento; // Corrigido de 'Empresa.Documento'

public class VerificacaoFormatacao extends ValidadorBase {
    @Override
    protected boolean processarValidacao(Documento documento) {
        System.out.println("-> Executando: Verificação de Formatação...");
        // Simulação: A formatação é considerada OK se o título não estiver vazio.
        // O uso do método 'trim()' é bom para tratar títulos que contenham apenas espaços em branco.
        if (documento.getTitulo() != null && !documento.getTitulo().trim().isEmpty()) {
            System.out.println("   [OK] Formatação aprovada.");
            return true;
        } else {
            System.out.println("   [FALHA] Formatação rejeitada: Título vazio.");
            return false;
        }
    }
}