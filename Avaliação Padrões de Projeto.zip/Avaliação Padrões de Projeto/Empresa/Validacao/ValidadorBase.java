// ValidadorBase.java
package Empresa.Validacao;

import Empresa.Documento.Documento;

/**
 * Implementação base para facilitar a criação de novos validadores.
 * Gerencia a referência para o próximo elemento na cadeia.
 */
public abstract class ValidadorBase implements Validador {
    
    private Validador proximo;

    @Override
    public Validador setProximo(Validador proximo) {
        this.proximo = proximo;
        return proximo;
    }

    /**
     * O método template que executa a lógica e decide se passa para o próximo.
     */
    @Override
    public boolean validar(Documento documento) {
        // 1. Tenta executar a validação específica da subclasse.
        if (!processarValidacao(documento)) {
            // A validação falhou, a cadeia é interrompida.
            return false;
        }

        // 2. Se a validação específica passou, verifica se há um próximo na cadeia.
        if (proximo != null) {
            // Chama o próximo elemento na cadeia.
            return proximo.validar(documento);
        }

        // 3. Se não há mais validadores e todos os anteriores passaram, o documento está aprovado.
        return true;
    }

    /**
     * Método abstrato que as subclasses devem implementar com sua lógica.
     * @param documento O documento a ser validado.
     * @return true se a validação passar, false se falhar.
     */
    protected abstract boolean processarValidacao(Documento documento);
}