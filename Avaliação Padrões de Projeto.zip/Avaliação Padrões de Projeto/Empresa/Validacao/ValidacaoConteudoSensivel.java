package Empresa.Validacao; // Corrigido de 'Empresa.Validacao'

import Empresa.Documento.Documento; // Corrigido de 'Empresa.Documento'

public class ValidacaoConteudoSensivel extends ValidadorBase {
    @Override
    protected boolean processarValidacao(Documento documento) {
        System.out.println("-> Executando: Validação de Conteúdo Sensível...");
        // Simulação: O documento falha se contiver a palavra "CONFIDENCIAL" no conteúdo.
        if (documento.getConteudo().toUpperCase().contains("CONFIDENCIAL")) {
            System.out.println("   [FALHA] Conteúdo sensível rejeitado.");
            return false;
        } else {
            System.out.println("   [OK] Conteúdo sensível aprovado.");
            return true;
        }
    }
}