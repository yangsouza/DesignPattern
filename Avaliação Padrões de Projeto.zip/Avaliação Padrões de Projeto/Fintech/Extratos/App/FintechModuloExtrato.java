package Fintech.Extratos.App;

import Fintech.Extratos.Fabrica.GeradorDeExtrato;
import Fintech.Extratos.Fabrica.GeradorSimplificado;
import Fintech.Extratos.Fabrica.GeradorDetalhado;

public class FintechModuloExtrato {
    
    public static void main(String[] args) {
        // Cliente 1 solicita um Extrato Simplificado
        System.out.println("-> Processando solicitação do Cliente 1: Extrato Simplificado");
        GeradorDeExtrato geradorSimplificado = new GeradorSimplificado();
        String extrato1 = geradorSimplificado.gerarExtratoCompleto();
        
        System.out.println("Resultado Final do Cliente 1:\n" + extrato1);
        
        System.out.println("\n=======================================================\n");

        // Cliente 2 solicita um Extrato Detalhado
        System.out.println("-> Processando solicitação do Cliente 2: Extrato Detalhado");
        GeradorDeExtrato geradorDetalhado = new GeradorDetalhado();
        String extrato2 = geradorDetalhado.gerarExtratoCompleto();

        System.out.println("Resultado Final do Cliente 2:\n" + extrato2);
    }
}