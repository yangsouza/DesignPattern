package Fintech.Extratos.Fabrica;

import Fintech.Extratos.Produto.Extrato;
import Fintech.Extratos.Produto.ExtratoDetalhado;

public class GeradorDetalhado extends GeradorDeExtrato {
    @Override
    protected Extrato criarExtrato() {
        return new ExtratoDetalhado();
    }
}