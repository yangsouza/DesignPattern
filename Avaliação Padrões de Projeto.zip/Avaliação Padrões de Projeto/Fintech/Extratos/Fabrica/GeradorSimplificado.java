package Fintech.Extratos.Fabrica;

import Fintech.Extratos.Produto.Extrato;
import Fintech.Extratos.Produto.ExtratoSimplificado;

public class GeradorSimplificado extends GeradorDeExtrato {
    @Override
    protected Extrato criarExtrato() {
        return new ExtratoSimplificado();
    }
}