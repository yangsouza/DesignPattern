package Fintech.Extratos.Fabrica;

import Fintech.Extratos.Produto.Extrato;

public abstract class GeradorDeExtrato {
    
    // Factory Method
    protected abstract Extrato criarExtrato();

    public String gerarExtratoCompleto() {
        Extrato extrato = criarExtrato(); 
        
        System.out.println("\n--- INICIANDO GERAÇÃO DE EXTRATO ---");
        extrato.coletarDados();
        extrato.calcularSaldo();
        extrato.formatar();
        System.out.println("--- GERAÇÃO CONCLUÍDA ---\n");
        
        return extrato.gerar();
    }
}