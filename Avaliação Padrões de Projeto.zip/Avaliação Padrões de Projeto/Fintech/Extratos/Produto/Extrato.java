package Fintech.Extratos.Produto;

public interface Extrato {
    void coletarDados();
    void calcularSaldo();
    void formatar();
    String gerar();
}