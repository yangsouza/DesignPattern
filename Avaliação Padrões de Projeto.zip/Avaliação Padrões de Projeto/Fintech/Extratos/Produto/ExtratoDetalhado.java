package Fintech.Extratos.Produto;

public class ExtratoDetalhado implements Extrato {
    private String dadosColetados;

    @Override
    public void coletarDados() {
        this.dadosColetados = "Dados detalhados de 10 transações, incluindo tags e categorias.";
        System.out.println("-> Extrato Detalhado: Coleta de dados com categorização e tags.");
    }
    // ... (demais métodos implementados)
    @Override
    public void calcularSaldo() {
        System.out.println("-> Extrato Detalhado: Saldo calculado com projeção de 30 dias.");
    }
    @Override
    public void formatar() {
        System.out.println("-> Extrato Detalhado: Formatando para tabela detalhada.");
    }
    @Override
    public String gerar() {
        return "EXTRATO DETALHADO: " + this.dadosColetados + " Saldo Projetado: R$ 6.100,00";
    }
}