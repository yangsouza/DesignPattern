package Fintech.Extratos.Produto;

public class ExtratoSimplificado implements Extrato {
    private String dadosColetados;

    @Override
    public void coletarDados() {
        this.dadosColetados = "Dados básicos de 10 transações.";
        System.out.println("-> Extrato Simplificado: Coleta de dados básicos finalizada.");
    }
    // ... (demais métodos implementados)
    @Override
    public void calcularSaldo() {
        System.out.println("-> Extrato Simplificado: Saldo calculado com base em transações liquidadas.");
    }
    @Override
    public void formatar() {
        System.out.println("-> Extrato Simplificado: Formatando para layout básico.");
    }
    @Override
    public String gerar() {
        return "EXTRATO SIMPLIFICADO: " + this.dadosColetados + " Saldo: R$ 5.450,00";
    }
}