package Plataforma.Principal;

import Plataforma.Contexto.PlataformaStreaming;
import Plataforma.Estrategia.RecomendacaoColaborativa;
import Plataforma.Estrategia.RecomendacaoHistorico;
import Plataforma.Estrategia.RecomendacaoPopularidade;

import java.util.List;

/**
 * Cliente: Demonstra a seleção dinâmica da estratégia.
 */
public class SistemaRecomendacaoApp {

    public static void main(String[] args) {
        String usuarioA = "usuario_premium_99";
        String usuarioB = "usuario_free_05";

        // 1. Configuração inicial: Usuário A começa com Estratégia de Popularidade.
        System.out.println("--- CENA 1: Usuário A com Estratégia Inicial (Popularidade) ---");
        PlataformaStreaming plataformaA = new PlataformaStreaming(new RecomendacaoPopularidade());

        List<String> recsA_popularidade = plataformaA.obterRecomendacoes(usuarioA);
        System.out.println("Recomendações para " + usuarioA + ": " + recsA_popularidade);


        // 2. Mudança de Estratégia em tempo de execução para o Usuário A (Baseado no Perfil/Ação).
        // A plataforma decide mudar para Filtragem Colaborativa.
        System.out.println("\n--- CENA 2: Mudança Dinâmica para Usuário A (Colaborativa) ---");
        plataformaA.setEstrategia(new RecomendacaoColaborativa());

        List<String> recsA_colaborativa = plataformaA.obterRecomendacoes(usuarioA);
        System.out.println("Recomendações para " + usuarioA + ": " + recsA_colaborativa);


        // 3. Usuário B utiliza outra Estratégia (Histórico).
        System.out.println("\n--- CENA 3: Novo Usuário B com Estratégia (Histórico) ---");
        PlataformaStreaming plataformaB = new PlataformaStreaming(new RecomendacaoHistorico());

        List<String> recsB_historico = plataformaB.obterRecomendacoes(usuarioB);
        System.out.println("Recomendações para " + usuarioB + ": " + recsB_historico);
    }
}