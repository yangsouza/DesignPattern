package Plataforma.Contexto;

import Plataforma.Estrategia.EstrategiaRecomendacao;
import java.util.List;

/**
 * Contexto: Mantém uma referência à Estratégia e permite que ela seja definida dinamicamente.
 */
public class PlataformaStreaming {
    private EstrategiaRecomendacao estrategia;

    /**
     * Construtor para definir a estratégia inicial.
     * @param estrategia A estratégia de recomendação a ser usada.
     */
    public PlataformaStreaming(EstrategiaRecomendacao estrategia) {
        this.estrategia = estrategia;
    }

    /**
     * Permite alterar a estratégia em tempo de execução (dinamicamente).
     * @param novaEstrategia A nova estratégia de recomendação.
     */
    public void setEstrategia(EstrategiaRecomendacao novaEstrategia) {
        System.out.println("\n*** Estratégia de recomendação ALTERADA para: " + novaEstrategia.getClass().getSimpleName() + " ***");
        this.estrategia = novaEstrategia;
    }

    /**
     * Executa a recomendação, delegando a chamada para o objeto Estratégia atual.
     * @param usuarioId O ID do usuário para quem a recomendação será feita.
     * @return A lista de conteúdos recomendados.
     */
    public List<String> obterRecomendacoes(String usuarioId) {
        System.out.println("\n*** Gerando recomendações para o usuário " + usuarioId + " ***");
        return estrategia.recomendarConteudo(usuarioId);
    }
}