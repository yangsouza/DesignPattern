package Plataforma.Estrategia;

import java.util.List;

/**
 * Interface Strategy: Define o contrato para todos os algoritmos de recomendação.
 */
public interface EstrategiaRecomendacao {
    List<String> recomendarConteudo(String usuarioId);
}