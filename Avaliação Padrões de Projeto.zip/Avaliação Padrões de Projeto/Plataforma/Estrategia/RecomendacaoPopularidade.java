package Plataforma.Estrategia;

import java.util.Arrays;
import java.util.List;

/**
 * Estratégia Concreta 1: Baseada em Popularidade.
 */
public class RecomendacaoPopularidade implements EstrategiaRecomendacao {

    @Override
    public List<String> recomendarConteudo(String usuarioId) {
        System.out.println("-> Algoritmo de Popularidade: Conteúdo mais assistido globalmente.");
        // Lógica de filtragem, pontuação e seleção baseada em popularidade...
        return Arrays.asList("Série Blockbuster", "Filme de Ação do Momento", "Documentário Top Global");
    }
}