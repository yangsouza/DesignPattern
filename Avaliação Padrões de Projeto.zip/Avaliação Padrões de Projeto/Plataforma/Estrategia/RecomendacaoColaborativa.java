package Plataforma.Estrategia;

import java.util.Arrays;
import java.util.List;

/**
 * Estratégia Concreta 3: Baseada em Filtragem Colaborativa.
 */
public class RecomendacaoColaborativa implements EstrategiaRecomendacao {

    @Override
    public List<String> recomendarConteudo(String usuarioId) {
        System.out.println("-> Algoritmo Colaborativo: Baseado no que usuários similares a " + usuarioId + " assistiram.");
        // Lógica de filtragem, pontuação e seleção colaborativa...
        return Arrays.asList("Conteúdo que 'vizinhos' gostaram", "Sugestão por afinidade de perfil", "Nova Produção Original da Plataforma");
    }
}