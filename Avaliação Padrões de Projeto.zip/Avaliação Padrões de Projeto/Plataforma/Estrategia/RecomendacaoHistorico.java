package Plataforma.Estrategia;

import java.util.Arrays;
import java.util.List;

/**
 * Estratégia Concreta 2: Baseada no Histórico do Usuário.
 */
public class RecomendacaoHistorico implements EstrategiaRecomendacao {

    @Override
    public List<String> recomendarConteudo(String usuarioId) {
        System.out.println("-> Algoritmo de Histórico do Usuário: Baseado em itens já assistidos pelo usuário " + usuarioId);
        // Lógica de filtragem, pontuação e seleção baseada no histórico...
        return Arrays.asList("Filme similar a Gênero X", "Próxima temporada de Série Y", "Sugestão de Ator Favorito");
    }
}