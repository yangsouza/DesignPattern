package Datacenter.Monitoramento.Servidor;

import java.util.ArrayList;
import java.util.List;
import DataCenter.Monitoramento.Modelo.Observer;
import Datacenter.Monitoramento.Modelo.Subject;

public class Servidor implements Subject {
    private final String nome;
    private String estado;
    private final List<Observer> observers;

    public Servidor(String nome, String estadoInicial) {
        this.nome = nome;
        this.estado = estadoInicial;
        this.observers = new ArrayList<>();
        System.out.println("Servidor " + nome + " inicializado com estado: " + estadoInicial);
    }

    // Implementação da interface Subject
    @Override
    public void adicionarObserver(Observer observer) {
        this.observers.add(observer);
        System.out.println("-> " + observer.getClass().getSimpleName() + " se inscreveu no servidor " + nome);
    }

    @Override
    public void removerObserver(Observer observer) {
        this.observers.remove(observer);
        System.out.println("-> " + observer.getClass().getSimpleName() + " cancelou a inscrição no servidor " + nome);
    }

    @Override
    public void notificarObservers() {
        System.out.println("\n*** Servidor " + nome + " mudou de estado para: " + this.estado + " ***");
        for (Observer observer : observers) {
            observer.atualizar(this.nome, this.estado);
        }
    }

    // Método que simula a mudanca de estado
    public void verificarSaude(String novoEstado) {
        if (!this.estado.equalsIgnoreCase(novoEstado)) {
            this.estado = novoEstado;
            // Se o estado mudou, notifica todos os observadores
            this.notificarObservers();
        } else {
            System.out.println("Servidor " + nome + " continua em estado: " + novoEstado);
        }
    }

    public String getNome() {
        return nome;
    }

    public String getEstado() {
        return estado;
    }
}