package DataCenter.Modelo;

/**
 * Interface para todos os observadores que querem ser notificados
 * sobre a mudanca de estado de um servidor.
 */
public interface Observer {
    void atualizar(String nomeServidor, String novoEstado);
}