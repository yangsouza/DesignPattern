package DataCenter.Modelo;
/**
 * Interface para o Assunto (Subject), que mantem uma lista de
 * observadores e os notifica sobre mudancas de estado.
 */
public interface Subject {
    void adicionarObserver(Observer observer);
    void removerObserver(Observer observer);
    void notificarObservers();
}