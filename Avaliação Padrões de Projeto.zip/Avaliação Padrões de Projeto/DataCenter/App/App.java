package Datacenter.Monitoramento.App;

import Datacenter.Monitoramento.Observadores.DashboardEmTempoReal;
import Datacenter.Monitoramento.Observadores.ModuloDeEscalonamento;
import Datacenter.Monitoramento.Observadores.SistemaDeTickets;
import Datacenter.Monitoramento.Servidor.Servidor;

public class App {
    public static void main(String[] args) {
        // 1. Cria o servidor (o Subject Concreto)
        Servidor webServer = new Servidor("WEB-01", "NORMAL");

        // 2. Cria os observadores (os componentes a serem notificados)
        DashboardEmTempoReal dashboard = new DashboardEmTempoReal();
        SistemaDeTickets ticketSystem = new SistemaDeTickets();
        ModuloDeEscalonamento escalonamento = new ModuloDeEscalonamento();

        // 3. Inscreve os observadores no servidor
        System.out.println("\n*** Inscrição de Componentes ***");
        webServer.adicionarObserver(dashboard);
        webServer.adicionarObserver(ticketSystem);
        webServer.adicionarObserver(escalonamento);
        System.out.println("********************************\n");

        // --- Simulação 1: Mudança de NORMAL para ALERTA ---
        System.out.println("--- SIMULACAO 1: Servidor passa para ALERTA ---");
        webServer.verificarSaude("ALERTA");

        // --- Simulação 2: Mudança de ALERTA para CRITICO ---
        System.out.println("\n--- SIMULACAO 2: Servidor passa para CRITICO ---");
        webServer.verificarSaude("CRITICO");
        
        // --- Simulação 3: Mudança de CRITICO para NORMAL ---
        System.out.println("\n--- SIMULACAO 3: Servidor volta para NORMAL ---");
        webServer.verificarSaude("NORMAL");

        // Demonstração de baixo acoplamento: Adicionar um novo componente
        System.out.println("\n*** Adicionando novo Observador em tempo de execução ***");
        webServer.adicionarObserver((nomeServidor, novoEstado) -> {
            System.out.println("[LOG_AUDITORIA] Mudança registrada: " + nomeServidor + " -> " + novoEstado);
        });

        // --- Simulação 4: Teste com novo observador ---
        System.out.println("\n--- SIMULACAO 4: Novo estado com Observador de Auditoria ---");
        webServer.verificarSaude("DESCONHECIDO");
    }
}