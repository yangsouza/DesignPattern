package Datacenter.Observadores;

import Datacenter.Modelo.Observer;

public class ModuloDeEscalonamento implements Observer {
    @Override
    public void atualizar(String nomeServidor, String novoEstado) {
        if ("CRITICO".equalsIgnoreCase(novoEstado)) {
            System.out.println("[ESCALONAMENTO] Servidor " + nomeServidor + " esta CRITICO! -> Iniciando provisionamento de novo recurso.");
        } else if ("NORMAL".equalsIgnoreCase(novoEstado)) {
            System.out.println("[ESCALONAMENTO] Servidor " + nomeServidor + " voltou ao NORMAL. -> Verificando possibilidade de desprovisionamento.");
        } else {
            System.out.println("[ESCALONAMENTO] Servidor " + nomeServidor + " -> Monitorando estado antes de acionar escalonamento.");
        }
    }
}