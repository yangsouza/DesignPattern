package Datacenter.Observadores;

import Datacenter.Modelo.Observer;

public class DashboardEmTempoReal implements Observer {
    @Override
    public void atualizar(String nomeServidor, String novoEstado) {
        System.out.println("[DASHBOARD] Servidor " + nomeServidor + " -> Exibindo estado atualizado: " + novoEstado);
    }
}