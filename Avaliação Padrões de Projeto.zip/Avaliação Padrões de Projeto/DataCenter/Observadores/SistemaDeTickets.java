package Datacenter.Observadores;

import Datacenter.Modelo.Observer;

public class SistemaDeTickets implements Observer {
    @Override
    public void atualizar(String nomeServidor, String novoEstado) {
        if ("CRITICO".equalsIgnoreCase(novoEstado)) {
            System.out.println("[TICKETS] Servidor " + nomeServidor + " esta CRITICO! -> Abrindo novo ticket de alta prioridade.");
        } else if ("ALERTA".equalsIgnoreCase(novoEstado)) {
            System.out.println("[TICKETS] Servidor " + nomeServidor + " esta em ALERTA. -> Abrindo ticket de baixa prioridade.");
        } else {
            System.out.println("[TICKETS] Servidor " + nomeServidor + " esta OK. -> Nenhuma acao necessaria.");
        }
    }
}